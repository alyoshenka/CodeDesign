Game Instructions

Use the WASD keys to move around the screen, eatins smaller fish and avoiding larger ones. 
The fish that are small enough to be eaten are displayed, as well as a health indicator.
The goal is to get grow big enough while avoiding being eaten.

Alexi Most AIE Programming 2020